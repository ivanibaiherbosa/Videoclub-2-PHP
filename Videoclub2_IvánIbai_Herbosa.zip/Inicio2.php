<?php
include_once "CintaVideo.php";
include_once "Dvd.php";
include_once "Juego.php";
include_once "Cliente.php";

//instanciamos un par de objetos cliente

$cliente1 = new Cliente("Bruce Wayne", 23);
$cliente2 = new Cliente("Clark Kent", 33);

//mostramos el número de cada cliente creado

echo "<br>El identificador del cliente 1 es: " . $cliente1->getNumero();
echo "<br>El identificador del cliente 2 es: " . $cliente2->getNumero();

//instancio algunos soportes

$soporte1 = new CintaVideo("Los cazafantasmas", 23, 3.5, 107);
$soporte2 = new Juego("The Last of Us Part II", 26, 49.99, "PS4", 1, 1);
$soporte3 = new Dvd("Origen", 24, 15, "es,en,fr", "16:9");
$soporte4 = new Dvd("El Imperio Contraataca", 4, 3, "es,en","16:9");

//alquilo algunos soportes

$cliente1->alquilarSoporte($soporte1);
$cliente1->alquilarSoporte($soporte2);
$cliente1->alquilarSoporte($soporte3);

//voy a intentar alquilar de nuevo un soporte que ya tiene alquilado

$cliente1->alquilarSoporte($soporte1);

//el cliente tiene 3 soportes en alquiler como máximo
//este soporte no lo va a poder alquilar

$cliente1->alquilarSoporte($soporte4);

//este soporte no lo tiene alquilado

$cliente1->devolver(4);

//devuelvo un soporte que sí que tiene alquilado

$cliente1->devolver(2);


?>